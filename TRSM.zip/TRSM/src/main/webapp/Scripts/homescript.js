/**
 * 
 */
var THIS_EMPLOYEE_USERNAME;
var THIS_EMPLOYEE_FULLNAME;
var THIS_EMPLOYEE_STARTDATE;
var THIS_EMPLOYEE_TOTALFUNDS;
var THIS_EMPLOYEE_PENDINGFUNDS;
var THIS_EMPLOYEE_AWARDEDFUNDS;
var THIS_EMPLOYEE_DEPTNAME;
var THIS_EMPLOYEE_EMPCODE;
var THIS_EMPLOYEE_HIGHERUP;
var THIS_EMPLOYEE_POSITION;

function translateEmpCode(code) {
	if(code == 1) {
		THIS_EMPLOYEE_POSITION = 'workerbee';
	}
	if(code == 2) {
		THIS_EMPLOYEE_POSITION = 'dronebee';
	}
	if(code == 3) {
		THIS_EMPLOYEE_POSITION = 'droneworker';
	}
	
	if(code == 4) {
		THIS_EMPLOYEE_POSITION = 'hivequeen';
	}
	if(code == 9) {
		THIS_EMPLOYEE_POSITION = 'admin';
	}
}


function openTab(evt, tabName, id) {
	var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className= " active";
    var curr = evt.currentTarget;
    
    //alert(id);
    if(id == 'profbtn') {
    	//alert('id equals profbtn');
    	translateEmpCode(THIS_EMPLOYEE_EMPCODE);
    	formatProfile(curr);
    	
    }
    if(id == 'newreqbtn') {
    	alert('id equals newreqbtn');
    }
    if(id == 'myreqsbtn') {
    	alert('id equals myreqsbtn');
    }
    //formatTab(curr);
    
  }

function formatProfile(tabobj) {
	
	//alert('format the profile!');
	//let profileheaderid = 'profileheader';
	//let sendheader = document.getElementById(profileheaderid);
	//sendheader.innerHTML = 'Employee Name:' + THIS_EMPLOYEE_NAME;
	document.getElementById("pname").innerHTML = "<strong>" + THIS_EMPLOYEE_FULLNAME + "</strong>";
	document.getElementById("puser").innerHTML = "<i> @" +THIS_EMPLOYEE_UNAME + "</i>";
	//todo if empcode = ? print sometype
	//todo add worker info (title: emptype in dept: hive_j 
	//						since: xx/xx/xxxx)
	let date = new Date(THIS_EMPLOYEE_STARTDATE);
	document.getElementById("pemptype").innerHTML = "Job Title: " + THIS_EMPLOYEE_POSITION;
	document.getElementById("pdept").innerHTML = "Department: " + THIS_EMPLOYEE_DEPTNAME;
	document.getElementById("psdate").innerHTML = "Since: " + date;
	document.getElementById("phup").innerHTML = "Reports to: " + THIS_EMPLOYEE_HIGHERUP;
	document.getElementById("pavfunds").innerHTML = "Available Funds: $" + THIS_EMPLOYEE_TOTALFUNDS;
	document.getElementById("ppfunds").innerHTML = "Pending Funds: $" + THIS_EMPLOYEE_PENDINGFUNDS;
	document.getElementById("pawfunds").innerHTML = "Awarded Funds: $" + THIS_EMPLOYEE_AWARDEDFUNDS;

	
}










function getEmployee(){
	//alert("called getEmployee")
	let url = "/TRSM/FrontController/employee";
	let xhr = new XMLHttpRequest();
	//alert("request initialized")
	let body = document.getElementById("bd");
	xhr.onreadystatechange = function(){
		if(xhr.status === 200 && xhr.readyState === 4){
			alert("yo")
			let employee = JSON.parse(xhr.responseText);
			
			THIS_EMPLOYEE_UNAME = employee["uname"];			
			THIS_EMPLOYEE_FULLNAME = employee["fullname"];
			THIS_EMPLOYEE_STARTDATE = employee["startDate"];
			THIS_EMPLOYEE_TOTALFUNDS= employee["totalFunds"];
			THIS_EMPLOYEE_PENDINGFUNDS= employee["pendingFunds"];
			THIS_EMPLOYEE_AWARDEDFUNDS= employee["awardedFunds"];
			THIS_EMPLOYEE_DEPTNAME = employee["deptname"];
			THIS_EMPLOYEE_EMPCODE= employee["empcode"];
			THIS_EMPLOYEE_HIGHERUP= employee["higherup"];

			
			let testid = 'tester';
			let test = document.getElementById(testid);
			test.innerHTML = 'welcome, ' + employeename;
			
			
			/*
			for(let e of employee){
				let row = document.createElement("tr");
				let mId = document.createElement("td");
				mId.innerHTML = e["uname"];
				let mTitle = document.createElement("td");
				mTitle.innerHTML = e["fullname"];
				let mGenre = document.createElement("td");
				mGenre.innerHTML = e["empcode"];
				row.appendChild(mId);
				row.appendChild(mTitle);
				row.appendChild(mGenre);
				body.appendChild(row);
			}*/
		}
	}
	
	xhr.open("POST", url);
	xhr.send();
}
/*
function Movie(id, name, genre, academy){
	this.id = id;
	this.movie_name = name;
	this.genre_id = genre;
	this.academy_id = academy;
}

function ajaxPostRequest(){
	let url = "/ServletDemo/AjaxPostRequest";
	let xhr = new XMLHttpRequest();
	
	let mId = document.getElementById("mId").value;
	let mTitle = document.getElementById("mTitle").value;
	let mGenre = document.getElementById("mGenre").value;
	let mAcademy = document.getElementById("mAcademy").value;
	
	let movie = new Movie(mId, mTitle, mGenre, mAcademy);
	
	xhr.onreadystatechange = function(){
		if(xhr.status === 200 && xhr.readyState === 4){
			console.log("Object Sent!")
		}
	}
	
	xhr.open("POST", url);
	xhr.send(JSON.stringify(movie));
}*/

//let submitButton = document.getElementById("theButton");

//submitButton.addEventListener("click", ajaxPostRequest);

window.onload = function() {
	getEmployee();
}