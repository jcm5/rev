import java.util.List;

import com.revature.models.Employee;
import com.revature.models.Request;
import com.revature.service.EmployeeService;
import com.revature.service.RequestService;

public class TestDrive {
	public static void main(String[] args) {
		EmployeeService es = new EmployeeService();
		
		//List<Employee> l = es.getAllEmployees();
		
		//for(Employee e : l) {
		//	System.out.println(e.toString());
		//}
		
		//System.out.println("------");
		Employee emp = new Employee(es.getEmployeeByID("workerbee1j"));
		
		//System.out.println(emp.toString());
		
		RequestService rs = new RequestService();
		List<Request> r = rs.getAllRequests();
		
		System.out.println("Reqs by Employee");
		System.out.println(rs.getRequestByEmployee(emp));
		
		System.out.println("Reqs by Key");
		String requestor = "workerbee1j";
		System.out.println(rs.getRequestByKey(requestor, 3));
		
		
		for(Request req: r)
			System.out.println(req.toString());
	}

}
