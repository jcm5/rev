package com.revature.repoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.revature.models.Employee;
import com.revature.models.Request;
import com.revature.repo.RequestRepo;
import com.revature.util.ConnectionClosers;
import com.revature.util.ConnectionFactory;

public class RequestRepoImpl implements RequestRepo{

	
	public List<Request> getAllRequests() {
		List<Request> reqs = new ArrayList<Request>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		final String SQL_QUERY = "select * from testmyscript.request";

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(SQL_QUERY);
			while (rs.next()) {
				reqs.add(
						new Request(
							rs.getString(1), rs.getInt(2), 
							rs.getDate(3), rs.getString(4),
							rs.getDouble(5), rs.getDouble(6), 
							rs.getBoolean(7),rs.getInt(8), 
							rs.getString(9),rs.getString(10), 
							rs.getBytes(11), rs.getBytes(12)));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return reqs;
	}
	
	
	public Request getRequestByKey(String requestor, int eventId) {
		Request r = new Request();
		Connection conn = null; // we NEED a connection to access our DB
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("select * from testmyscript.request where requestor = ? and eventid = ?");
			stmt.setString(1, requestor);
			stmt.setInt(2, eventId);
			rs = stmt.executeQuery();
			if (rs.next()) {
				r.setRequestor(rs.getString(1));
				r.setEventId(rs.getInt(2));
				r.setSubmitDate(rs.getDate(3));
				r.setJustification(rs.getString(4));
				r.setProjectedReimbursment(rs.getDouble(5));
				r.setProjectedReimbursment(rs.getDouble(6));
				r.setUrgent(rs.getBoolean(7));
				r.setApprovalStatus(rs.getInt(8));
				r.setDenialReason(rs.getString(9));
				r.setRefundIncreaseJustification(rs.getString(10));
				r.setEventAttachment(rs.getBytes(11));
				r.setApprovalAttachment(rs.getBytes(12));
			}
		} catch (SQLException er) {
			er.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return r;
	}


	
	public void insertRequest(Request r) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("insert into testmyscript.request values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			stmt.setString(1, r.getRequestor());
			stmt.setInt(2, r.getEventId());
			stmt.setDate(3, r.getSubmitDate());
			stmt.setString(4, r.getJustification());
			stmt.setDouble(5, r.getProjectedReimbursment());
			stmt.setDouble(6, r.getGrantedReimbursment());
			stmt.setBoolean(7, r.isUrgent());
			stmt.setInt(8, r.getApprovalStatus());
			stmt.setString(9, r.getDenialReason());
			stmt.setString(10, r.getRefundIncreaseJustification());
			stmt.setBytes(11, r.getEventAttachment());
			stmt.setBytes(12, r.getApprovalAttachment());
			stmt.execute();

		} catch (SQLException er) {
			er.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}
	}

	
	public void deleteRequest(Request r) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("delete from testmyscript.request where (requestor = ? and eventId = ?)");
			stmt.setString(1, r.getRequestor());
			stmt.setInt(2, r.getEventId());
			
			stmt.execute();

		} catch (SQLException er) {
			er.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}			
	}

	
	public void updateRequest(Request r) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("update testmyscript.request set requestor = ?, "
					+ "eventid= ?, submitdate = ?, justification = ?, projectedreimbursment = ?, "
					+ "grantedreimbursment= ?, isurgent = ?, approvalstatus = ?, denialreason = ?, "
					+ "refundincreasejustification= ?, eventattachment = ?, approvalattachment = ?,"
					+ " where (requestor = ? and eventid = ?)");
			stmt.setString(1, r.getRequestor());
			stmt.setInt(2, r.getEventId());
			stmt.setDate(3, r.getSubmitDate());
			stmt.setString(4, r.getJustification());
			stmt.setDouble(5, r.getProjectedReimbursment());
			stmt.setDouble(6, r.getGrantedReimbursment());
			stmt.setBoolean(7, r.isUrgent());
			stmt.setInt(8, r.getApprovalStatus());
			stmt.setString(9, r.getDenialReason());
			stmt.setString(10, r.getRefundIncreaseJustification());
			stmt.setBytes(11, r.getEventAttachment());
			stmt.setBytes(12, r.getApprovalAttachment());
			stmt.execute();
		} catch (SQLException e2) {
			e2.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}
	}

	// TODO TEST THIS METHOD
	//It may not work
	
	public List<Request> getEmployeeRequests(Employee e) {
		List<Request> reqs = new ArrayList<Request>();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null; 
		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement(("select * from testmyscript.request where requestor = ?"));
			stmt.setString(1, e.getUname());
			rs = stmt.executeQuery();
			while (rs.next()) {
				reqs.add(
						new Request(
							rs.getString(1), rs.getInt(2), 
							rs.getDate(3), rs.getString(4),
							rs.getDouble(5), rs.getDouble(6), 
							rs.getBoolean(7),rs.getInt(8), 
							rs.getString(9),rs.getString(10), 
							rs.getBytes(11), rs.getBytes(12)));
			}

		} catch (SQLException e2) {
			e2.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return reqs;
	}
}
