package com.revature.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.revature.models.Employee;
import com.revature.service.EmployeeService;

public class RequestHelper {

	public static Object processGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		String uri = request.getRequestURI().replace("/TRSM","");
		switch(uri) {
		case "/FrontController":
			System.out.println("Sad!");
		case "FrontController/employee":
			return "what the fuck man";
		
		default:
			return "no such endpoint fool";
		}
	}
	
	
	public static Object processPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		System.out.println("INITIAL REQUEST URI: " + request.getRequestURI());
		String uri = request.getRequestURI().replace("/TRSM","");
		System.out.println("ALTERED REQUEST URI: " + uri);

		switch(uri) {
		case "/FrontController":
			EmployeeService es = new EmployeeService();
			String username = request.getParameter("uname_grabme");
			String password = request.getParameter("pass_grabme");	
			System.out.println("WAAAGAAAAA");
			
			//todo check with database to see if user exists
			Employee e = es.getEmployeeByID(username);
			int employeecode = e.getEmpcode();
			if(employeecode == 1 || employeecode == 2 ) {
				HttpSession session = request.getSession();
				session.setAttribute("role", employeecode);
				session.setAttribute("user", username);
				response.sendRedirect("Pages/home.html");
				//request.getRequestDispatcher("/employee").forward(request, response);
				return e;
			}
			else {
				response.sendRedirect("index.html");
				return("Invalid Login");
			}
		//case "FrontController/employee":
		case "/FrontController/employee":
			EmployeeService es2 = new EmployeeService();
			System.out.println("FROM THE SESSION ATTRIBUTE");
			HttpSession session = request.getSession(true);
			System.out.println(session.getAttribute("user"));
			Object obj = session.getAttribute("user");
			String username2 = obj.toString();
			Employee e2 = es2.getEmployeeByID(username2);
			response.setContentType("application/json");
			ObjectMapper imTheMap = new ObjectMapper();
			return e2;



			
		
		default:
			return "no such endpoint son!";
		}
	}
}
