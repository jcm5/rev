package com.revature.repo;

import java.util.List;

import com.revature.models.Employee;
import com.revature.models.Request;

public interface RequestRepo {
	List<Request> getAllRequests();
	Request getRequestByKey(String requestor, int eventId);
	void insertRequest(Request r);
	void deleteRequest(Request r);
	void updateRequest(Request r);

	List<Request> getEmployeeRequests(Employee e);

}
