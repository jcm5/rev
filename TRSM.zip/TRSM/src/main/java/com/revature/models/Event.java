package com.revature.models;

import java.sql.Date;

public class Event {
	private int eventId;
	private String title;
	private String eventType;
	private String description;
	private Date startDate;
	private Date endDate;
	private String address;
	private double passingGrade;
	private double eventCost;
	public Event() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Event(int eventId, String title, String eventType, String description, Date startDate, Date endDate,
			String address, double passingGrade, double eventCost) {
		super();
		this.eventId = eventId;
		this.title = title;
		this.eventType = eventType;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.address = address;
		this.passingGrade = passingGrade;
		this.eventCost = eventCost;
	}
	public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getEventType() {
		return eventType;
	}
	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public double getPassingGrade() {
		return passingGrade;
	}
	public void setPassingGrade(double passingGrade) {
		this.passingGrade = passingGrade;
	}
	public double getEventCost() {
		return eventCost;
	}
	public void setEventCost(double eventCost) {
		this.eventCost = eventCost;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		long temp;
		temp = Double.doubleToLongBits(eventCost);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + eventId;
		result = prime * result + ((eventType == null) ? 0 : eventType.hashCode());
		temp = Double.doubleToLongBits(passingGrade);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Event other = (Event) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (Double.doubleToLongBits(eventCost) != Double.doubleToLongBits(other.eventCost))
			return false;
		if (eventId != other.eventId)
			return false;
		if (eventType == null) {
			if (other.eventType != null)
				return false;
		} else if (!eventType.equals(other.eventType))
			return false;
		if (Double.doubleToLongBits(passingGrade) != Double.doubleToLongBits(other.passingGrade))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Event [eventId=" + eventId + ", title=" + title + ", eventType=" + eventType + ", description="
				+ description + ", startDate=" + startDate + ", endDate=" + endDate + ", address=" + address
				+ ", passingGrade=" + passingGrade + ", eventCost=" + eventCost + "]";
	}
}


