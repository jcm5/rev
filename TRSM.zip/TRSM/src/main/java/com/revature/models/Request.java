package com.revature.models;

import java.sql.Date;
import java.util.Arrays;

public class Request {
	private String requestor;
	private int eventId;
	private Date submitDate;
	private String justification;
	private double projectedReimbursment;
	private double grantedReimbursment;
	private boolean isUrgent;
	private int approvalStatus;
	private String denialReason;
	private String refundIncreaseJustification;
	private byte[] eventAttachment;
	private byte[] approvalAttachment;
	
	public Request() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Request(String requestor, int eventId, Date submitDate, String justification, double projectedReimbursment,
			double grantedReimbursment, boolean isUrgent, int approvalStatus, String denialReason,
			String refundIncreaseJustification, byte[] eventAttachment, byte[] approvalAttachment) {
		super();
		this.requestor = requestor;
		this.eventId = eventId;
		this.submitDate = submitDate;
		this.justification = justification;
		this.projectedReimbursment = projectedReimbursment;
		this.grantedReimbursment = grantedReimbursment;
		this.isUrgent = isUrgent;
		this.approvalStatus = approvalStatus;
		this.denialReason = denialReason;
		this.refundIncreaseJustification = refundIncreaseJustification;
		this.eventAttachment = eventAttachment;
		this.approvalAttachment = approvalAttachment;
	}

	public String getRequestor() {
		return requestor;
	}

	public void setRequestor(String requestor) {
		this.requestor = requestor;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public Date getSubmitDate() {
		return submitDate;
	}

	public void setSubmitDate(Date submitDate) {
		this.submitDate = submitDate;
	}

	public String getJustification() {
		return justification;
	}

	public void setJustification(String justification) {
		this.justification = justification;
	}

	public double getProjectedReimbursment() {
		return projectedReimbursment;
	}

	public void setProjectedReimbursment(double projectedReimbursment) {
		this.projectedReimbursment = projectedReimbursment;
	}

	public double getGrantedReimbursment() {
		return grantedReimbursment;
	}

	public void setGrantedReimbursment(double grantedReimbursment) {
		this.grantedReimbursment = grantedReimbursment;
	}

	public boolean isUrgent() {
		return isUrgent;
	}

	public void setUrgent(boolean isUrgent) {
		this.isUrgent = isUrgent;
	}

	public int getApprovalStatus() {
		return approvalStatus;
	}

	public void setApprovalStatus(int approvalStatus) {
		this.approvalStatus = approvalStatus;
	}

	public String getDenialReason() {
		return denialReason;
	}

	public void setDenialReason(String denialReason) {
		this.denialReason = denialReason;
	}

	public String getRefundIncreaseJustification() {
		return refundIncreaseJustification;
	}

	public void setRefundIncreaseJustification(String refundIncreaseJustification) {
		this.refundIncreaseJustification = refundIncreaseJustification;
	}

	public byte[] getEventAttachment() {
		return eventAttachment;
	}

	public void setEventAttachment(byte[] eventAttachment) {
		this.eventAttachment = eventAttachment;
	}

	public byte[] getApprovalAttachment() {
		return approvalAttachment;
	}

	public void setApprovalAttachment(byte[] approvalAttachment) {
		this.approvalAttachment = approvalAttachment;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(approvalAttachment);
		result = prime * result + approvalStatus;
		result = prime * result + ((denialReason == null) ? 0 : denialReason.hashCode());
		result = prime * result + Arrays.hashCode(eventAttachment);
		result = prime * result + eventId;
		long temp;
		temp = Double.doubleToLongBits(grantedReimbursment);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + (isUrgent ? 1231 : 1237);
		result = prime * result + ((justification == null) ? 0 : justification.hashCode());
		temp = Double.doubleToLongBits(projectedReimbursment);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((refundIncreaseJustification == null) ? 0 : refundIncreaseJustification.hashCode());
		result = prime * result + ((requestor == null) ? 0 : requestor.hashCode());
		result = prime * result + ((submitDate == null) ? 0 : submitDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Request other = (Request) obj;
		if (!Arrays.equals(approvalAttachment, other.approvalAttachment))
			return false;
		if (approvalStatus != other.approvalStatus)
			return false;
		if (denialReason == null) {
			if (other.denialReason != null)
				return false;
		} else if (!denialReason.equals(other.denialReason))
			return false;
		if (!Arrays.equals(eventAttachment, other.eventAttachment))
			return false;
		if (eventId != other.eventId)
			return false;
		if (Double.doubleToLongBits(grantedReimbursment) != Double.doubleToLongBits(other.grantedReimbursment))
			return false;
		if (isUrgent != other.isUrgent)
			return false;
		if (justification == null) {
			if (other.justification != null)
				return false;
		} else if (!justification.equals(other.justification))
			return false;
		if (Double.doubleToLongBits(projectedReimbursment) != Double.doubleToLongBits(other.projectedReimbursment))
			return false;
		if (refundIncreaseJustification == null) {
			if (other.refundIncreaseJustification != null)
				return false;
		} else if (!refundIncreaseJustification.equals(other.refundIncreaseJustification))
			return false;
		if (requestor == null) {
			if (other.requestor != null)
				return false;
		} else if (!requestor.equals(other.requestor))
			return false;
		if (submitDate == null) {
			if (other.submitDate != null)
				return false;
		} else if (!submitDate.equals(other.submitDate))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Request [requestor=" + requestor + ", eventId=" + eventId + ", submitDate=" + submitDate
				+ ", justification=" + justification + ", projectedReimbursment=" + projectedReimbursment
				+ ", grantedReimbursment=" + grantedReimbursment + ", isUrgent=" + isUrgent + ", approvalStatus="
				+ approvalStatus + ", denialReason=" + denialReason + ", refundIncreaseJustification="
				+ refundIncreaseJustification + ", eventAttachment=" + Arrays.toString(eventAttachment)
				+ ", approvalAttachment=" + Arrays.toString(approvalAttachment) + "]";
	}

	
	

}
