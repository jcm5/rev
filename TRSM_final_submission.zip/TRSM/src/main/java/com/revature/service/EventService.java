package com.revature.service;

import java.util.List;

import com.revature.models.Employee;
import com.revature.models.Event;
import com.revature.repoimpl.EventRepoImpl;

public class EventService {

	public List<Event> getAllEvents() {
		return new EventRepoImpl().getAllEvents();
	}
	
	public List<Event> getEventByEmployee(Employee e) {
		return new EventRepoImpl().getEmployeeEvents(e);
	}
	public Event getEventById(int id) {
		return new EventRepoImpl().getEventById(id);
	}
	
	public void insertEvent(Event m) {
		new EventRepoImpl().insertEvent(m);
	}
	
	public void deleteEvent(Event m) {
		new EventRepoImpl().deleteEvent(m);		
	}
	
	public void updateEvent(Event m) {
		new EventRepoImpl().updateEvent(m);
	}
}
