package com.revature.repo;

import java.util.List;

import com.revature.models.Employee;

public interface EmployeeRepo {
	List<Employee> getAllEmployees();
	Employee getEmployeeByUname(String uname);
	void insertEmployee(Employee e);
	void deleteEmployee(Employee e);
	void updateEmployee(Employee e);
}
