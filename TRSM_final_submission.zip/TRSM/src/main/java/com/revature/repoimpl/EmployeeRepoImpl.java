package com.revature.repoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.revature.models.Employee;
import com.revature.repo.EmployeeRepo;
import com.revature.util.ConnectionClosers;
import com.revature.util.ConnectionFactory;

public class EmployeeRepoImpl implements EmployeeRepo{

	
	public List<Employee> getAllEmployees() {
		List<Employee> emps = new ArrayList<Employee>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		final String SQL_QUERY = "select * from testmyscript.employee";

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(SQL_QUERY);
			while (rs.next()) {
				emps.add(
						new Employee(
							rs.getString(1), rs.getString(2), 
							rs.getString(3), rs.getDate(4), 
							rs.getDouble(5), rs.getDouble(6),
							rs.getDouble(7), rs.getString(8),
							rs.getInt(9), rs.getString(10)));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return emps;
	}

	// TODO F I X T H I S
	
	public Employee getEmployeeByUname(String uname) {
		Employee e = new Employee();
		Connection conn = null; // we NEED a connection to access our DB
		PreparedStatement stmt = null;
		ResultSet rs = null;
		System.out.println("Uname : " + uname);

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("select * from testmyscript.employee where uname = ?");
			stmt.setString(1, uname);
			rs = stmt.executeQuery();
			if (rs.next()) {
				e.setUname(rs.getString(1));
				e.setPword(rs.getString(2));
				e.setFullname(rs.getString(3));
				e.setStartDate(rs.getDate(4));
				e.setTotalFunds(rs.getDouble(5));
				e.setPendingFunds(rs.getDouble(6));
				e.setAwardedFunds(rs.getDouble(7));
				e.setDeptname(rs.getString(8));
				e.setEmpcode(rs.getInt(9));
				e.setHigherup(rs.getString(10));
			}
		} catch (SQLException er) {
			er.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return e;
	}

	
	public void insertEmployee(Employee e) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("insert into testmyscript.employee values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			stmt.setString(1, e.getUname());
			stmt.setString(2, e.getPword());
			stmt.setString(3, e.getFullname());
			stmt.setDate(4, e.getStartDate());
			stmt.setDouble(5, e.getTotalFunds());
			stmt.setDouble(6, e.getPendingFunds());
			stmt.setDouble(7, e.getAwardedFunds());
			stmt.setString(8, e.getDeptname());
			stmt.setInt(9, e.getEmpcode());
			stmt.setString(10, e.getHigherup());
			stmt.execute();

		} catch (SQLException er) {
			er.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}		
	}

	
	public void deleteEmployee(Employee e) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("delete from testmyscript.employee where (uname = ?)");
			stmt.setString(1, e.getUname());
			stmt.execute();

		} catch (SQLException er) {
			er.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}		
	}

	public void updateEmployee(Employee e) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("update testmyscript.employee set uname = ?, "
					+ "pword = ?, fullname = ?, startdate= ?, totalfunds= ?, pendingfunds = ?, "
					+ "awardedfunds = ?, deptname = ?, empcode = ?, higherup = ? where (uname = ?)");
			stmt.setString(1, e.getUname());
			stmt.setString(2, e.getPword());
			stmt.setString(1, e.getFullname());
			stmt.setDate(2, e.getStartDate());
			stmt.setDouble(1, e.getTotalFunds());
			stmt.setDouble(2, e.getPendingFunds());
			stmt.setDouble(1, e.getAwardedFunds());
			stmt.setString(2, e.getDeptname());
			stmt.setInt(1, e.getEmpcode());
			stmt.setString(1, e.getHigherup());
			stmt.execute();
		} catch (SQLException e2) {
			e2.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}
	}

}
