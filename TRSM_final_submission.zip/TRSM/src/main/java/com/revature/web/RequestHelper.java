package com.revature.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.revature.models.Employee;
import com.revature.models.Event;
import com.revature.models.Request;
import com.revature.service.EmployeeService;
import com.revature.service.EventService;
import com.revature.service.RequestService;

public class RequestHelper {

	public static Object processGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		String uri = request.getRequestURI().replace("/TRSM","");
		switch(uri) {
		case "/FrontController":
			System.out.println("Sad!");
		case "FrontController/employee":
			return "what the heck man";					
		//case "/FrontController/StoreEvent":
		//	ObjectMapper map = new ObjectMapper();
		//	Event e = map.readValue(request.getInputStream(), Event.class);
		//	System.out.println("Please work." + e.toString());
		default:
			return "no such endpoint fool";
		}
	}
	
	
	public static Object processPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException{
		System.out.println("INITIAL REQUEST URI: " + request.getRequestURI());
		String uri = request.getRequestURI().replace("/TRSM","");
		System.out.println("ALTERED REQUEST URI: " + uri);

		switch(uri) {
		case "/FrontController":
			EmployeeService es = new EmployeeService();
			String username = request.getParameter("uname_grabme");
			String password = request.getParameter("pass_grabme");	
			System.out.println("WAAAGAAAAA");
			
			//todo check with database to see if user exists
			Employee e = es.getEmployeeByID(username);
			int employeecode = e.getEmpcode();
			if(employeecode == 1) {
				HttpSession session = request.getSession();
				session.setAttribute("role", "workerbee");
				session.setAttribute("user", username);
				response.sendRedirect("Pages/home.html");
				//request.getRequestDispatcher("/employee").forward(request, response);
				return e;
			}
			else {
				response.sendRedirect("index.html");
				return("Invalid Login");
			}
		//case "FrontController/employee":
		case "/FrontController/employee":
			EmployeeService es2 = new EmployeeService();
			System.out.println("FROM THE SESSION ATTRIBUTE");
			HttpSession session = request.getSession(true);
			System.out.println(session.getAttribute("user"));
			Object obj = session.getAttribute("user");
			String username2 = obj.toString();
			Employee e2 = es2.getEmployeeByID(username2);
			response.setContentType("application/json");
			return e2;

			
		case "/FrontController/getEmployeeRequests":
			EmployeeService es3 = new EmployeeService();
			RequestService rs = new RequestService();
			EventService evs = new EventService();
			System.out.println("FROM THE SESSION ATTRIBUTE");
			HttpSession session2 = request.getSession(true);
			System.out.println(session2.getAttribute("user"));
			Object obj2 = session2.getAttribute("user");
			String username3 = obj2.toString();
			Employee e3 = es3.getEmployeeByID(username3);
			List<Request> reqs = rs.getRequestByEmployee(e3);
			response.setContentType("application/json");

			return (reqs);
		
		case "/FrontController/getEmployeeEvents":
			EmployeeService es4 = new EmployeeService();
			RequestService r2 = new RequestService();
			EventService evs2 = new EventService();
			System.out.println("FROM THE SESSION ATTRIBUTE");
			HttpSession session3 = request.getSession(true);
			System.out.println(session3.getAttribute("user"));
			Object obj3 = session3.getAttribute("user");
			String username4 = obj3.toString();
			Employee e4 = es4.getEmployeeByID(username4);
			List<Event> eventlist = evs2.getEventByEmployee(e4);
			response.setContentType("application/json");
			System.out.println(eventlist);
			return (eventlist);
			
		//case "/FrontController/StoreEvent":
			//System.out.println("hello");
			//processGet(request, response);
			
			//ObjectMapper map = new ObjectMapper();
			//Event newevent = map.readValue(request.getInputStream(), newevent.class);
			//System.out.println("NEW EVENT: "+ newevent.toString());
			//HttpSession session4 = request.getSession(true);
			//System.out.println("IN THE STORE EVENT! " + session4.getAttribute("user"));
			//EventService evs3 = new EventService();
			///evs3.insertEvent(newevent);
			//List<Event> evlist = evs3.getAllEvents();
			//for(Event ee : evlist)
		//		System.out.println(ee.toString() + '\n');
				
		
		
		
		default:
			return "no such endpoint son!";
		}
	}
}
