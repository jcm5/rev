/**
 * 
 */
var THIS_EMPLOYEE_USERNAME;
var THIS_EMPLOYEE_FULLNAME;
var THIS_EMPLOYEE_STARTDATE;
var THIS_EMPLOYEE_TOTALFUNDS;
var THIS_EMPLOYEE_PENDINGFUNDS;
var THIS_EMPLOYEE_AWARDEDFUNDS;
var THIS_EMPLOYEE_DEPTNAME;
var THIS_EMPLOYEE_EMPCODE;
var THIS_EMPLOYEE_HIGHERUP;
var THIS_EMPLOYEE_POSITION;
var THIS_EMPLOYEE_REQUESTS;
var THIS_EMPLOYEE_EVENTS;

//Todo more of these to do this with other conversions
function translateEmpCode(code) {
	if(code == 1) {
		THIS_EMPLOYEE_POSITION = 'workerbee';
	}
	if(code == 2) {
		THIS_EMPLOYEE_POSITION = 'dronebee';
	}
	if(code == 3) {
		THIS_EMPLOYEE_POSITION = 'droneworker';
	}
	
	if(code == 4) {
		THIS_EMPLOYEE_POSITION = 'hivequeen';
	}
	if(code == 9) {
		THIS_EMPLOYEE_POSITION = 'admin';
	}
}


function openTab(evt, tabName, id) {
	var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className= " active";
    var curr = evt.currentTarget;
    
    //alert(id);
    if(id == 'profbtn') {
    	//alert('id equals profbtn');
    	formatProfile(curr);
    	
    }
    if(id == 'newreqbtn') {
    	//alert('id equals newreqbtn');
    }
    if(id == 'myreqsbtn') {
    	formatMyRequests(curr);

    }
    //formatTab(curr);
    
  }


function formatMyRequests(tabobj) {
	var writehere = document.getElementById("helltest");
	let i = 0;
	while(i < (THIS_EMPLOYEE_REQUESTS.length+1)) {
			let reqnum = document.createElement("h4");
			reqnum.innerHTML = "Request #"+THIS_EMPLOYEE_DEPTNAME+"00"+THIS_EMPLOYEE_EMPCODE+"00"+i;
			
			//TODO add recipient info
			let titl = document.createElement("p");
			titl.innerHTML= "<i><strong>"+THIS_EMPLOYEE_EVENTS[i]["title"]+"</strong></i>"; 
			
			
			let evid = document.createElement("p");
			evid.innerHTML = "Event Type: "+ THIS_EMPLOYEE_EVENTS[i]["eventType"] +" (ID="+THIS_EMPLOYEE_REQUESTS[i]["eventId"]+")";
			
			let sd = document.createElement("p");
			sd.innerHTML ="Submitted on: "+THIS_EMPLOYEE_REQUESTS[i]["submitDate"];
			
			//TODO move this down with the events
			let wjust= document.createElement("p");
			wjust.innerHTML ="Work Justification: "+THIS_EMPLOYEE_REQUESTS[i]["justification"];
			
			//TODO write conversions from event cost
			let projrein = document.createElement("p");
			projrein.innerHTML ="Projected Reimbursment: $"+THIS_EMPLOYEE_REQUESTS[i]["projectedReimbursment"];
			
			let grantrein = document.createElement("p");
			grantrein.innerHTML ="Granted Reimbursment: $"+THIS_EMPLOYEE_REQUESTS[i]["grantedReimbursment"];
			
			//TODO put in header or footer, mark bold/red if true
			let isurg = document.createElement("p");
			isurg.innerHTML ="Urgent = "+THIS_EMPLOYEE_REQUESTS[i]["isUrgent"];
			
			//TODO Convert to n/a or approved for presentations
			let grade = document.createElement("p");
			grade.innerHTML ="Grade: "+THIS_EMPLOYEE_REQUESTS[i]["gradeRecieved"];
			
			//TODO Convert to pending/denied/approved
			let appstatus= document.createElement("p");
			appstatus.innerHTML ="Status: "+THIS_EMPLOYEE_REQUESTS[i]["approvalStatus"];
			
			
			//TODO Hide if null
			let denialr = document.createElement("p");
			denialr.innerHTML ="<hr>Reason for denial: "+THIS_EMPLOYEE_REQUESTS[i]["denialReason"];
			
			//TODO Hide if null
			let refinj = document.createElement("p");
			refinj.innerHTML ="Reason for refund increase: "+THIS_EMPLOYEE_REQUESTS[i]["refundIncreaseJustification"];
			
			//TODO Hide if null
			let eventatt= document.createElement("p");
			eventatt.innerHTML ="Event attachment: "+THIS_EMPLOYEE_REQUESTS[i]["eventAttachment"];
			
			//TODO Hide if null, find good way to do this. maybe href?
			let approvatt= document.createElement("p");
			approvatt.innerHTML ="Approval attachment: "+THIS_EMPLOYEE_REQUESTS[i]["approvalAttachment"];

			//TODO MAYBE add message parameter to request table? that way it could be easily retrieved.
			
			writehere.appendChild(reqnum);
			writehere.appendChild(titl);
			writehere.appendChild(evid);
			writehere.appendChild(sd);
			writehere.appendChild(wjust);
			writehere.appendChild(projrein);
			writehere.appendChild(grantrein);
			writehere.appendChild(isurg);
			writehere.appendChild(grade);
			writehere.appendChild(appstatus);
			writehere.appendChild(denialr);
			writehere.appendChild(refinj);
			writehere.appendChild(eventatt);
			writehere.appendChild(approvatt);
			i++;
			}
}


function formatProfile(tabobj) {
	
	document.getElementById("pname").innerHTML = "<strong>" + THIS_EMPLOYEE_FULLNAME + "</strong>";
	document.getElementById("puser").innerHTML = "<i> @" +THIS_EMPLOYEE_UNAME + "</i>";
	let date = new Date(THIS_EMPLOYEE_STARTDATE);
	document.getElementById("pemptype").innerHTML = "Job Title: " + THIS_EMPLOYEE_POSITION;
	document.getElementById("pdept").innerHTML = "Department: " + THIS_EMPLOYEE_DEPTNAME;
	document.getElementById("psdate").innerHTML = "Since: " + date;
	document.getElementById("phup").innerHTML = "Reports to: " + THIS_EMPLOYEE_HIGHERUP;
	document.getElementById("pavfunds").innerHTML = "Available Funds: $" + THIS_EMPLOYEE_TOTALFUNDS;
	document.getElementById("ppfunds").innerHTML = "Pending Funds: $" + THIS_EMPLOYEE_PENDINGFUNDS;
	document.getElementById("pawfunds").innerHTML = "Awarded Funds: $" + THIS_EMPLOYEE_AWARDEDFUNDS;
}




function getEmployee(){
	let url = "/TRSM/FrontController/employee";
	let xhr = new XMLHttpRequest();
	let body = document.getElementById("bd");
	xhr.onreadystatechange = function(){
		if(xhr.status === 200 && xhr.readyState === 4){
			let employee = JSON.parse(xhr.responseText);
			
			THIS_EMPLOYEE_UNAME = employee["uname"];			
			THIS_EMPLOYEE_FULLNAME = employee["fullname"];
			THIS_EMPLOYEE_STARTDATE = employee["startDate"];
			THIS_EMPLOYEE_TOTALFUNDS= employee["totalFunds"];
			THIS_EMPLOYEE_PENDINGFUNDS= employee["pendingFunds"];
			THIS_EMPLOYEE_AWARDEDFUNDS= employee["awardedFunds"];
			THIS_EMPLOYEE_DEPTNAME = employee["deptname"];
			THIS_EMPLOYEE_EMPCODE= employee["empcode"];
			THIS_EMPLOYEE_HIGHERUP= employee["higherup"];
	    	translateEmpCode(THIS_EMPLOYEE_EMPCODE);
		}
	}
	
	xhr.open("POST", url);
	xhr.send();
}

function getEmployeeRequests(){
	let url = "/TRSM/FrontController/getEmployeeRequests";
	let xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function(){
		if(xhr.status === 200 && xhr.readyState === 4){
			THIS_EMPLOYEE_REQUESTS= JSON.parse(xhr.responseText);
		}
	}
	
	xhr.open("POST", url);
	xhr.send();
}

function getEmployeeEvents(){
	let url = "/TRSM/FrontController/getEmployeeEvents";
	let xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function(){
		if(xhr.status === 200 && xhr.readyState === 4){
			THIS_EMPLOYEE_EVENTS= JSON.parse(xhr.responseText);
		}
	}
	
	xhr.open("POST", url);
	xhr.send();
}

//function addRequest(){
//	
//}
/*
function Event(eventId, title, eventType, description, startDate, endDate,
		address, passingGrade, eventCost) {
	this.eventId = eventId;
	this.title = title;
	this.eventType = eventType;
	this.description = description;
	this.startDate = startDate;
	this.endDate = endDate;
	this.address = address;
	this.passingGrade = passingGrade;
	this.eventCost = eventCost;
}


function Request(requestor, eventId, submitDate, justification, projectedReimbursment,
		grantedReimbursment, isUrgent, gradeRecieved, approvalStatus, denialReason,
		refundIncreaseJustification, eventAttachment, approvalAttachment) {
	this.requestor = requestor;
	this.eventId = eventId;
	this.submitDate = submitDate;
	this.justification = justification;
	this.projectedReimbursment = projectedReimbursment;
	this.grantedReimbursment = grantedReimbursment;
	this.isUrgent = isUrgent;
	this.gradeRecieved = gradeRecieved;
	this.approvalStatus = approvalStatus;
	this.denialReason = denialReason;
	this.refundIncreaseJustification = refundIncreaseJustification;
	this.eventAttachment = eventAttachment;
	this.approvalAttachment = approvalAttachment;
}

function ajaxPostRequest(){
	let url = "/TRSM/FrontController/StoreEvent";
	let xhr = new XMLHttpRequest();
	
	let eventId = "default";
	let title = document.getElementById("evttle").value;
	let eventType = document.getElementById("evid").value;
	let description = document.getElementById("desc");
	let startDate = document.getElementById("evStartTime").value;
	let endDate = document.getElementById("evEndDate").value;
	let address = document.getElementById("loc").value;
	
	if(document.getElementById("grdfrmt").value == "scored")
		var returnformat = document.getElementById("gcoff").value;
	else
		var returnformat = null;
	let passingGrade = returnformat;
	let eventCost = document.getElementById("costof").value;
	
	let newevent = new Event(eventId, title, eventType, description, startDate, endDate, address, passingGrade, eventCost);
	alert(newevent);
	xhr.onreadystatechange = function(){
		if(xhr.status === 200 && xhr.readyState === 4){
			console.log("Object Sent!");
		}
	}
	
	xhr.open("POST", url);
	xhr.send(JSON.stringify(newevent));
}

let submitButton = document.getElementById("submitreq");

submitButton.addEventListener("click", ajaxPostRequest);
*/



window.onload = function() {
	getEmployee();
	getEmployeeRequests();
	getEmployeeEvents();
}