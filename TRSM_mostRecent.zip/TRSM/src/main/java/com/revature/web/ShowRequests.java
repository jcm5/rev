package com.revature.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.revature.models.Employee;
import com.revature.service.EmployeeService;
import com.revature.service.EventService;
import com.revature.service.RequestService;

public class ShowRequests extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ShowRequests() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		EmployeeService es = new EmployeeService();
		EventService ev = new EventService();
		RequestService rs = new RequestService();
		System.out.println("In the ShowRequest servlet...");
		Object a = request.getSession().getAttribute("user");
		String username = a.toString();
				
		
		
		Employee e = es.getEmployeeByID(username);		
		
		
		String employeeinfo_jsonstring = "";
		String eventinfo_jsonstring = "";
		String requestinfo_jsonstring = "";
		
		
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		
		
		ObjectMapper imTheMap = new ObjectMapper();
		PrintWriter pw = response.getWriter();
		
		//request.getRequestDispatcher("./Pages/ViewRequests.html").forward(request, response);
		
		
		
		response.getOutputStream().write(imTheMap.writeValueAsBytes(es.getEmployeeByID(username)));
		//pw.println(imTheMap.writeValueAsString(es.getEmployeeByID(username)));
		
		
		employeeinfo_jsonstring = imTheMap.writeValueAsString(es.getEmployeeByID(username));
		eventinfo_jsonstring = imTheMap.writeValueAsString(ev.getAllEvents());
		requestinfo_jsonstring = imTheMap.writeValueAsString(rs.getRequestByEmployee(e));
		
		System.out.println("JSON EMPLOYEE STRING: " + employeeinfo_jsonstring);
		System.out.println("JSON EVENT INFO STRING: " + eventinfo_jsonstring);
		System.out.println("JSON REQUEST INFO STRING: " + requestinfo_jsonstring);		
		
		
		
		//response.sendRedirect();
		
		
		/*
		String name = request.getParameter("fullname_grabme");
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String empname = e.getFullname().toString();
		System.out.println(empname);
		pw.print("<h1>HELLO empname</h1>");
		*/
	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
