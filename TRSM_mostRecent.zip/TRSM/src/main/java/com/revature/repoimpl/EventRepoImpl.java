package com.revature.repoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.revature.models.Employee;
import com.revature.models.Event;
import com.revature.repo.EventRepo;
import com.revature.util.ConnectionClosers;
import com.revature.util.ConnectionFactory;

public class EventRepoImpl implements EventRepo{

	
	public List<Event> getAllEvents() {
		List<Event> events = new ArrayList<Event>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		final String SQL_QUERY = "select * from testmyscript.events";

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(SQL_QUERY);
			while (rs.next()) {
				events.add(
						new Event(
							rs.getInt(1), rs.getString(2), 
							rs.getString(3), rs.getString(4), 
							rs.getDate(5), rs.getDate(6),
							rs.getString(7), rs.getDouble(8),
							rs.getDouble(9)));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return events;
	}

	
	public Event getEventById(int id) {
		Event e = new Event();
		Connection conn = null; // we NEED a connection to access our DB
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("select * from testmyscript.events where eventid = ?");
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			if (rs.next()) {
				e.setTitle(rs.getString(1));
				e.setEventType(rs.getString(2));
				e.setDescription(rs.getString(3));
				e.setStartDate(rs.getDate(4));
				e.setEndDate(rs.getDate(5));
				e.setAddress(rs.getString(6));
				e.setPassingGrade(rs.getDouble(7));
				e.setEventCost(rs.getDouble(8));
			}
		} catch (SQLException er) {
			er.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return e;
	}
	

	
	public void insertEvent(Event e) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("insert into testmyscript.events values(?, ?, ?, ?, ?, ?, ?, ?, ?)");
			stmt.setInt(1, e.getEventId());
			stmt.setString(2, e.getTitle());
			stmt.setString(3, e.getEventType());
			stmt.setString(4, e.getDescription());
			stmt.setDate(5, e.getStartDate());
			stmt.setDate(6, e.getEndDate());
			stmt.setString(7, e.getAddress());
			stmt.setDouble(8, e.getPassingGrade());
			stmt.setDouble(9, e.getEventCost());
			stmt.execute();

		} catch (SQLException er) {
			er.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}		
		
	}

	
	public void deleteEvent(Event e) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("delete from testmyscript.events where (EventId = ?)");
			stmt.setInt(1, e.getEventId());
			stmt.execute();

		} catch (SQLException er) {
			er.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}		
	}

	
	public void updateEvent(Event e) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("update testmyscript.events set eventid = ?, "
					+ "title= ?, eventtype = ?, description = ?, startdate = ?, enddate = ?, "
					+ "address = ?, passinggrade = ?, eventcost = ? where (member_id = ?)");
			stmt.setInt(1, e.getEventId());
			stmt.setString(2, e.getTitle());
			stmt.setString(1, e.getEventType());
			stmt.setString(2, e.getDescription());
			stmt.setDate(1, e.getStartDate());
			stmt.setDate(2, e.getEndDate());
			stmt.setString(1, e.getAddress());
			stmt.setDouble(2, e.getPassingGrade());
			stmt.setDouble(1, e.getEventCost());
			stmt.execute();
		} catch (SQLException e2) {
			e2.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}
		
	}
	
	
	
	
	//TODO
	
	public List<Event> getEmployeeEvents(Employee e) {
		List<Event> events = new ArrayList<Event>();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement( 
					"select e.* from testmyscript.events as e, "
					+ "testmyscript.request as r WHERE "
					+ "r.requestor=? and "
					+ "r.eventid = e.eventid;");
		stmt.setString(1, e.getUname());
			rs = stmt.executeQuery();
			while (rs.next()) {
				events.add(
						new Event(
							rs.getInt(1), rs.getString(2), 
							rs.getString(3), rs.getString(4), 
							rs.getDate(5), rs.getDate(6),
							rs.getString(7), rs.getDouble(8),
							rs.getDouble(9)));
			}

		} catch (SQLException e2) {
			e2.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return events;
	}


	
}
