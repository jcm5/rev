package com.revature.service;

import java.util.List;

import com.revature.models.Employee;
import com.revature.repoimpl.EmployeeRepoImpl;

public class EmployeeService {

	public List<Employee> getAllEmployees() {
		return new EmployeeRepoImpl().getAllEmployees();
	}
	
	public Employee getEmployeeByID(String uname) {
		return new EmployeeRepoImpl().getEmployeeByUname(uname);
	}
	
	public void insertEmployee(Employee m) {
		new EmployeeRepoImpl().insertEmployee(m);
	}
	
	public void deleteEmployee(Employee m) {
		new EmployeeRepoImpl().deleteEmployee(m);		
	}
	
	public void updateEmployee(Employee m) {
		new EmployeeRepoImpl().updateEmployee(m);
	}
}
