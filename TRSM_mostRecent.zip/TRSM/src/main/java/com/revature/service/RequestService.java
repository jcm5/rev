package com.revature.service;

import java.util.List;

import com.revature.models.Employee;
import com.revature.models.Request;
import com.revature.repoimpl.RequestRepoImpl;

public class RequestService {
	public List<Request> getAllRequests() {
		return new RequestRepoImpl().getAllRequests();
	}
	
	public List<Request> getRequestByEmployee(Employee e) {
		return new RequestRepoImpl().getEmployeeRequests(e);
	}
	public Request getRequestByKey(String requestor, int eventId) {
		return new RequestRepoImpl().getRequestByKey(requestor, eventId);
	}
	
	public void insertRequest(Request m) {
		new RequestRepoImpl().insertRequest(m);
	}
	
	public void deleteRequest(Request m) {
		new RequestRepoImpl().deleteRequest(m);		
	}
	
	public void updateRequest(Request m) {
		new RequestRepoImpl().updateRequest(m);
	}

}
