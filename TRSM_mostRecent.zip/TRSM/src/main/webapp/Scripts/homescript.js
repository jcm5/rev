/**
 * 
 */
var THIS_EMPLOYEE_USERNAME;
var THIS_EMPLOYEE_FULLNAME;
var THIS_EMPLOYEE_STARTDATE;
var THIS_EMPLOYEE_TOTALFUNDS;
var THIS_EMPLOYEE_PENDINGFUNDS;
var THIS_EMPLOYEE_AWARDEDFUNDS;
var THIS_EMPLOYEE_DEPTNAME;
var THIS_EMPLOYEE_EMPCODE;
var THIS_EMPLOYEE_HIGHERUP;
var THIS_EMPLOYEE_POSITION;
var THIS_EMPLOYEE_REQUESTS;
var THIS_EMPLOYEE_EVENTS;

//Todo more of these to do this with other conversions
function translateEmpCode(code) {
	if(code == 1) {
		THIS_EMPLOYEE_POSITION = 'workerbee';
	}
	if(code == 2) {
		THIS_EMPLOYEE_POSITION = 'dronebee';
	}
	if(code == 3) {
		THIS_EMPLOYEE_POSITION = 'droneworker';
	}
	
	if(code == 4) {
		THIS_EMPLOYEE_POSITION = 'hivequeen';
	}
	if(code == 9) {
		THIS_EMPLOYEE_POSITION = 'admin';
	}
}


function openTab(evt, tabName, id) {
	var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
      tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
      tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className= " active";
    var curr = evt.currentTarget;
    
    //alert(id);
    if(id == 'profbtn') {
    	//alert('id equals profbtn');
    	formatProfile(curr);
    	
    }
    if(id == 'newreqbtn') {
    	alert('id equals newreqbtn');
    }
    if(id == 'myreqsbtn') {
    	formatMyRequests(curr);

    }
    //formatTab(curr);
    
  }


function formatMyRequests(tabobj) {
	var writehere = document.getElementById("helltest");
	let i = 0;
	while(i < (THIS_EMPLOYEE_REQUESTS.length+1)) {
			let reqnum = document.createElement("h4");
			reqnum.innerHTML = "Request #"+THIS_EMPLOYEE_DEPTNAME+"00"+THIS_EMPLOYEE_EMPCODE+"00"+i;
			
			//TODO add recipient info
			let titl = document.createElement("h5");
			titl.innerHTML= THIS_EMPLOYEE_EVENTS[i]["title"]; 
			
			
			let evid = document.createElement("p");
			evid.innerHTML = "Event Type: "+ THIS_EMPLOYEE_EVENTS[i]["eventType"] +" (ID="+THIS_EMPLOYEE_REQUESTS[i]["eventId"]+")";
			
			let sd = document.createElement("p");
			sd.innerHTML ="Submitted on: "+THIS_EMPLOYEE_REQUESTS[i]["submitDate"];
			
			//TODO move this down with the events
			let wjust= document.createElement("p");
			wjust.innerHTML ="Work Justification: "+THIS_EMPLOYEE_REQUESTS[i]["justification"];
			
			//TODO write conversions from event cost
			let projrein = document.createElement("p");
			projrein.innerHTML ="Projected Reimbursment: $"+THIS_EMPLOYEE_REQUESTS[i]["projectedReimbursment"];
			
			let grantrein = document.createElement("p");
			grantrein.innerHTML ="Granted Reimbursment: $"+THIS_EMPLOYEE_REQUESTS[i]["grantedReimbursment"];
			
			//TODO put in header or footer, mark bold/red if true
			let isurg = document.createElement("p");
			isurg.innerHTML ="Urgent = "+THIS_EMPLOYEE_REQUESTS[i]["isUrgent"];
			
			//TODO Convert to n/a or approved for presentations
			let grade = document.createElement("p");
			grade.innerHTML ="Grade: "+THIS_EMPLOYEE_REQUESTS[i]["gradeRecieved"];
			
			//TODO Convert to pending/denied/approved
			let appstatus= document.createElement("p");
			appstatus.innerHTML ="Status: "+THIS_EMPLOYEE_REQUESTS[i]["approvalStatus"];
			
			
			//TODO Hide if null
			let denialr = document.createElement("p");
			denialr.innerHTML ="<hr>Reason for denial: "+THIS_EMPLOYEE_REQUESTS[i]["denialReason"];
			
			//TODO Hide if null
			let refinj = document.createElement("p");
			refinj.innerHTML ="Reason for refund increase: "+THIS_EMPLOYEE_REQUESTS[i]["refundIncreaseJustification"];
			
			//TODO Hide if null
			let eventatt= document.createElement("p");
			eventatt.innerHTML ="Event attachment: "+THIS_EMPLOYEE_REQUESTS[i]["eventAttachment"];
			
			//TODO Hide if null, find good way to do this. maybe href?
			let approvatt= document.createElement("p");
			approvatt.innerHTML ="Approval attachment: "+THIS_EMPLOYEE_REQUESTS[i]["approvalAttachment"];

			//TODO MAYBE add message parameter to request table? that way it could be easily retrieved.
			
			writehere.appendChild(reqnum);
			writehere.appendChild(evid);
			writehere.appendChild(sd);
			writehere.appendChild(wjust);
			writehere.appendChild(projrein);
			writehere.appendChild(grantrein);
			writehere.appendChild(isurg);
			writehere.appendChild(grade);
			writehere.appendChild(appstatus);
			writehere.appendChild(denialr);
			writehere.appendChild(refinj);
			writehere.appendChild(eventatt);
			writehere.appendChild(approvatt);
			i++;
			}
}


function formatProfile(tabobj) {
	
	document.getElementById("pname").innerHTML = "<strong>" + THIS_EMPLOYEE_FULLNAME + "</strong>";
	document.getElementById("puser").innerHTML = "<i> @" +THIS_EMPLOYEE_UNAME + "</i>";
	let date = new Date(THIS_EMPLOYEE_STARTDATE);
	document.getElementById("pemptype").innerHTML = "Job Title: " + THIS_EMPLOYEE_POSITION;
	document.getElementById("pdept").innerHTML = "Department: " + THIS_EMPLOYEE_DEPTNAME;
	document.getElementById("psdate").innerHTML = "Since: " + date;
	document.getElementById("phup").innerHTML = "Reports to: " + THIS_EMPLOYEE_HIGHERUP;
	document.getElementById("pavfunds").innerHTML = "Available Funds: $" + THIS_EMPLOYEE_TOTALFUNDS;
	document.getElementById("ppfunds").innerHTML = "Pending Funds: $" + THIS_EMPLOYEE_PENDINGFUNDS;
	document.getElementById("pawfunds").innerHTML = "Awarded Funds: $" + THIS_EMPLOYEE_AWARDEDFUNDS;
}




function getEmployee(){
	let url = "/TRSM/FrontController/employee";
	let xhr = new XMLHttpRequest();
	let body = document.getElementById("bd");
	xhr.onreadystatechange = function(){
		if(xhr.status === 200 && xhr.readyState === 4){
			let employee = JSON.parse(xhr.responseText);
			
			THIS_EMPLOYEE_UNAME = employee["uname"];			
			THIS_EMPLOYEE_FULLNAME = employee["fullname"];
			THIS_EMPLOYEE_STARTDATE = employee["startDate"];
			THIS_EMPLOYEE_TOTALFUNDS= employee["totalFunds"];
			THIS_EMPLOYEE_PENDINGFUNDS= employee["pendingFunds"];
			THIS_EMPLOYEE_AWARDEDFUNDS= employee["awardedFunds"];
			THIS_EMPLOYEE_DEPTNAME = employee["deptname"];
			THIS_EMPLOYEE_EMPCODE= employee["empcode"];
			THIS_EMPLOYEE_HIGHERUP= employee["higherup"];
	    	translateEmpCode(THIS_EMPLOYEE_EMPCODE);
		}
	}
	
	xhr.open("POST", url);
	xhr.send();
}

function getEmployeeRequests(){
	let url = "/TRSM/FrontController/getEmployeeRequests";
	let xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function(){
		if(xhr.status === 200 && xhr.readyState === 4){
			THIS_EMPLOYEE_REQUESTS= JSON.parse(xhr.responseText);
		}
	}
	
	xhr.open("POST", url);
	xhr.send();
}

function getEmployeeEvents(){
	let url = "/TRSM/FrontController/getEmployeeEvents";
	let xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function(){
		if(xhr.status === 200 && xhr.readyState === 4){
			THIS_EMPLOYEE_EVENTS= JSON.parse(xhr.responseText);
		}
	}
	
	xhr.open("POST", url);
	xhr.send();
}

//function addRequest(){
//	
//}



/*
function Movie(id, name, genre, academy){
	this.id = id;
	this.movie_name = name;
	this.genre_id = genre;
	this.academy_id = academy;
}

function ajaxPostRequest(){
	let url = "/ServletDemo/AjaxPostRequest";
	let xhr = new XMLHttpRequest();
	
	let mId = document.getElementById("mId").value;
	let mTitle = document.getElementById("mTitle").value;
	let mGenre = document.getElementById("mGenre").value;
	let mAcademy = document.getElementById("mAcademy").value;
	
	let movie = new Movie(mId, mTitle, mGenre, mAcademy);
	
	xhr.onreadystatechange = function(){
		if(xhr.status === 200 && xhr.readyState === 4){
			console.log("Object Sent!")
		}
	}
	
	xhr.open("POST", url);
	xhr.send(JSON.stringify(movie));
}*/

//let submitButton = document.getElementById("theButton");

//submitButton.addEventListener("click", ajaxPostRequest);

window.onload = function() {
	getEmployee();
	getEmployeeRequests();
	getEmployeeEvents();
}