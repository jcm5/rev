package com.revature.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.revature.service.EmployeeService;

public class RequestHelper {

	public static Object processGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uri = request.getRequestURI().replace("/TRSM/FrontController", "");
		System.out.println("MY URI: "+uri);
		switch(uri) {
		//this endpoint returns a list of members
		case "/login":
			System.out.println("success!");
			//return new EmployeeService().getAllEmployees();
			//could still access request.getParameter and such
			
		//this is the default endpoint if no match is found	
		default:
			return "no such endpoint";
		}
	}
}
