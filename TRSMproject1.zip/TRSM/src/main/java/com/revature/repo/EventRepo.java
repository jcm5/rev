package com.revature.repo;

import java.util.List;

import com.revature.models.Employee;
import com.revature.models.Event;

public interface EventRepo {
	List<Event> getAllEvents();
	Event getEventById(int id);
	void insertEvent(Event e);
	void deleteEvent(Event e);
	void updateEvent(Event e);

	List<Event> getEmployeeEvents(Employee e);
}
