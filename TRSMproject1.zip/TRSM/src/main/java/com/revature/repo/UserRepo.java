package com.revature.repo;

import java.util.List;

import com.revature.models.User;

public interface UserRepo {
	List<User> getAllUsers();
	User getUserByUname(int id);
	void insertUser(User u);
	void deleteUser(User u);
	void updateUser(User u);
}
