package com.revature.repoimpl;

import java.util.List;

import com.revature.models.User;
import com.revature.repo.UserRepo;

public class UserRepoImpl implements UserRepo{

	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUserByUname(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insertUser(User u) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteUser(User u) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateUser(User u) {
		// TODO Auto-generated method stub
		
	}

}
