package com.revature.repoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.revature.models.Employee;
import com.revature.models.Request;
import com.revature.repo.RequestRepo;
import com.revature.util.ConnectionClosers;
import com.revature.util.ConnectionFactory;

public class RequestRepoImpl implements RequestRepo{

	@Override
	public List<Request> getAllRequests() {
		List<Request> reqs = new ArrayList<Request>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		final String SQL_QUERY = "select * from testmyscript.request";

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(SQL_QUERY);
			while (rs.next()) {
				reqs.add(
						new Request(
							rs.getString(1), rs.getInt(2), 
							rs.getDate(3), rs.getDouble(4), 
							rs.getDouble(5), rs.getBoolean(6),
							rs.getInt(7), rs.getString(8),
							rs.getString(9), rs.getDate(10),
							rs.getDate(11)));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return reqs;
	}
	
	@Override
	public Request getRequestByKey(String requestor, int eventId) {
		Request r = new Request();
		Connection conn = null; // we NEED a connection to access our DB
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("select * from testmyscript.event where requestor = ? and eventid = ?");
			stmt.setString(1, requestor);
			stmt.setInt(2, eventId);
			rs = stmt.executeQuery();
			if (rs.next()) {
				r.setRequestor(rs.getString(1));
				r.setEventId(rs.getInt(2));
				r.setSubmitDate(rs.getDate(3));
				r.setProjectedReimbursment(rs.getDouble(4));
				r.setProjectedReimbursment(rs.getDouble(5));
				r.setUrgent(rs.getBoolean(6));
				r.setApprovalStatus(rs.getInt(7));
				r.setRefundIncreaseJustification(rs.getString(8));
				r.setEventAttachment(rs.getDate(9));
				r.setApprovalAttachment(rs.getDate(10));
			}
		} catch (SQLException er) {
			er.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return r;
	}


	@Override
	public void insertRequest(Request r) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("insert into testmyscript.event values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			stmt.setString(1, r.getRequestor());
			stmt.setInt(2, r.getEventId());
			stmt.setDate(3, r.getSubmitDate());
			stmt.setDouble(4, r.getProjectedReimbursment());
			stmt.setDouble(5, r.getGrantedReimbursment());
			stmt.setBoolean(6, r.isUrgent());
			stmt.setInt(7, r.getApprovalStatus());
			stmt.setString(8, r.getDenialReason());
			stmt.setString(9, r.getRefundIncreaseJustification());
			stmt.setDate(10, r.getEventAttachment());
			stmt.setDate(10, r.getApprovalAttachment());
			stmt.execute();

		} catch (SQLException er) {
			er.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}
	}

	@Override
	public void deleteRequest(Request r) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("delete from testmyscript.request where (requestor = and eventId = ?)");
			stmt.setString(1, r.getRequestor());
			stmt.setInt(2, r.getEventId());
			
			stmt.execute();

		} catch (SQLException er) {
			er.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}			
	}

	@Override
	public void updateRequest(Request r) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("update testmyscript.request set requestor = ?, "
					+ "eventid= ?, submitdate = ?, justification = ?, projectedreimbursment = ?, "
					+ "grantedreimbursment= ?, isurgent = ?, approvalstatus = ?, denialreason = ?, "
					+ "refundincreasejustification= ?, eventattachment = ?, approvalattachment = ?,"
					+ " where (requestor = ? and eventid = ?)");
			stmt.setString(1, r.getRequestor());
			stmt.setInt(2, r.getEventId());
			stmt.setDate(1, r.getSubmitDate());
			stmt.setDouble(2, r.getProjectedReimbursment());
			stmt.setDouble(1, r.getGrantedReimbursment());
			stmt.setBoolean(2, r.isUrgent());
			stmt.setInt(1, r.getApprovalStatus());
			stmt.setString(2, r.getDenialReason());
			stmt.setString(1, r.getRefundIncreaseJustification());
			stmt.setDate(1, r.getEventAttachment());
			stmt.setDate(1, r.getApprovalAttachment());
			stmt.execute();
		} catch (SQLException e2) {
			e2.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}
	}

	// TODO TEST THIS METHOD
	//It may not work
	@Override
	public List<Request> getEmployeeRequests(Employee e) {
		List<Request> reqs = new ArrayList<Request>();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null; 
		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement(("select * from testmyscript.request where requestor = ?"));
			stmt.setString(1, e.getUname());
			rs = stmt.executeQuery();
			while (rs.next()) {
				reqs.add(
						new Request(
							rs.getString(1), rs.getInt(2), 
							rs.getDate(3), rs.getDouble(4), 
							rs.getDouble(5), rs.getBoolean(6),
							rs.getInt(7), rs.getString(8),
							rs.getString(9), rs.getDate(10),
							rs.getDate(11)));
			}

		} catch (SQLException e2) {
			e2.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return reqs;
	}
}
