package com.revature.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.revature.models.Employee;
import com.revature.service.EmployeeService;

public class FrontController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	public FrontController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//if (request.getMethod().contentEquals("GET")) {
			EmployeeService es = new EmployeeService();
		
			String username = request.getParameter("uname_grabme");
			String password = request.getParameter("pass_grabme");
			System.out.println(username);
			System.out.println(password);
			
			Employee e = es.getEmployeeByID(username);
			System.out.println(e.toString());
			response.sendRedirect("Pages/home.html");
			
			
			//ObjectMapper mappy = new ObjectMapper();
			//response.getOutputStream().write(mappy.writeValueAsBytes(RequestHelper.processGet(request, response)));
		//}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
