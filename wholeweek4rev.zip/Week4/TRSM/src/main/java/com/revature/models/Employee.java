package com.revature.models;

import java.sql.Date;

public class Employee {
	private String uname;
	private String pword;
	private String fullname;
	private Date startDate;
	private double totalFunds;
	private double pendingFunds;
	private double awardedFunds;
	private String deptname;
	private int empcode;
	private String higherup;
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(Employee e) {
		this.uname = e.getUname();
		this.pword = e.pword;
		this.fullname = e.fullname;
		this.startDate = e.startDate;
		this.totalFunds = e.totalFunds;
		this.pendingFunds = e.pendingFunds;
		this.awardedFunds = e.awardedFunds;
		this.deptname = e.deptname;
		this.empcode = e.empcode;
		this.higherup = e.higherup;
		
	}
	public Employee(String uname, String pword, String fullname, Date startDate, double totalFunds, double pendingFunds,
			double awardedFunds, String deptname, int empcode, String higherup) {
		super();
		this.uname = uname;
		this.pword = pword;
		this.fullname = fullname;
		this.startDate = startDate;
		this.totalFunds = totalFunds;
		this.pendingFunds = pendingFunds;
		this.awardedFunds = awardedFunds;
		this.deptname = deptname;
		this.empcode = empcode;
		this.higherup = higherup;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPword() {
		return pword;
	}
	public void setPword(String pword) {
		this.pword = pword;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public double getTotalFunds() {
		return totalFunds;
	}
	public void setTotalFunds(double totalFunds) {
		this.totalFunds = totalFunds;
	}
	public double getPendingFunds() {
		return pendingFunds;
	}
	public void setPendingFunds(double pendingFunds) {
		this.pendingFunds = pendingFunds;
	}
	public double getAwardedFunds() {
		return awardedFunds;
	}
	public void setAwardedFunds(double awardedFunds) {
		this.awardedFunds = awardedFunds;
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	public int getEmpcode() {
		return empcode;
	}
	public void setEmpcode(int empcode) {
		this.empcode = empcode;
	}
	public String getHigherup() {
		return higherup;
	}
	public void setHigherup(String higherup) {
		this.higherup = higherup;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(awardedFunds);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((deptname == null) ? 0 : deptname.hashCode());
		result = prime * result + empcode;
		result = prime * result + ((fullname == null) ? 0 : fullname.hashCode());
		result = prime * result + ((higherup == null) ? 0 : higherup.hashCode());
		temp = Double.doubleToLongBits(pendingFunds);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((pword == null) ? 0 : pword.hashCode());
		temp = Double.doubleToLongBits(totalFunds);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((uname == null) ? 0 : uname.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (Double.doubleToLongBits(awardedFunds) != Double.doubleToLongBits(other.awardedFunds))
			return false;
		if (deptname == null) {
			if (other.deptname != null)
				return false;
		} else if (!deptname.equals(other.deptname))
			return false;
		if (empcode != other.empcode)
			return false;
		if (fullname == null) {
			if (other.fullname != null)
				return false;
		} else if (!fullname.equals(other.fullname))
			return false;
		if (higherup == null) {
			if (other.higherup != null)
				return false;
		} else if (!higherup.equals(other.higherup))
			return false;
		if (Double.doubleToLongBits(pendingFunds) != Double.doubleToLongBits(other.pendingFunds))
			return false;
		if (pword == null) {
			if (other.pword != null)
				return false;
		} else if (!pword.equals(other.pword))
			return false;
		if (Double.doubleToLongBits(totalFunds) != Double.doubleToLongBits(other.totalFunds))
			return false;
		if (uname == null) {
			if (other.uname != null)
				return false;
		} else if (!uname.equals(other.uname))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Employee [uname=" + uname + ", pword=" + pword + ", fullname=" + fullname + ", totalFunds=" + totalFunds
				+ ", pendingFunds=" + pendingFunds + ", awardedFunds=" + awardedFunds + ", deptname=" + deptname
				+ ", empcode=" + empcode + ", higherup=" + higherup + "]";
	}
	
	
}