package com.revature.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.revature.model.Destination;
import com.revature.model.Member;
import com.revature.repository.DestinationRepository;
import com.revature.util.ConnectionClosers;
import com.revature.util.ConnectionFactory;

public class DestinationRepositoryImpl implements DestinationRepository {

	public List<Destination> getAllDestinations() {
		List<Destination> dests = new ArrayList<Destination>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		final String SQL_QUERY = "select * from clubmanagerschema.destinations";

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(SQL_QUERY);
			while (rs.next()) {
				dests.add(
						new Destination(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getString(5)));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return dests;	}

	public Destination getDestinationById(int id) {
		Destination d = new Destination();
		Connection conn = null; // 
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("select * from clubmanagerschema.destinations where destination_id = ?");
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			if (rs.next()) {
				d.setDestination_id(rs.getInt(1));
				d.setName(rs.getString(2));
				d.setAddress(rs.getString(3));
				d.setCost_per_person(rs.getInt(4));
				d.setAdditional_notes(rs.getString(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return d;	}

	public void insertDestination(Destination d) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("insert into clubmanagerschema.destinations values(default, ?, ?, ?, ?)");
			stmt.setString(1, d.getName());
			stmt.setString(2, d.getAddress());
			stmt.setInt(3, d.getCost_per_person());
			stmt.setString(4, d.getAdditional_notes());
			stmt.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}
	}

	public void deleteDestination(Destination d) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("delete from clubmanagerschema.destinations where (destination_id = ?)");
			stmt.setInt(1, d.getDestination_id());
			stmt.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}
	}

	public void updateDestination(Destination d) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("update clubmanagerschema.destinations set destination_id = ?, "
					+ "destination_name = ?, address = ?,cost_per_person = ?,  additional_notes = ? where (destination_id = ?)");
			stmt.setInt(1, d.getDestination_id());
			stmt.setString(2, d.getName());
			stmt.setString(3, d.getAddress());
			stmt.setInt(4, d.getCost_per_person());
			stmt.setString(5, d.getAdditional_notes());
			stmt.setInt(6, d.getDestination_id());
			stmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}
	}

}
