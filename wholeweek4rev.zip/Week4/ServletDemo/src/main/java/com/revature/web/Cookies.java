package com.revature.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Cookies extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Cookies() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Cookie chocolateChip = new Cookie("cookieykey", "cookieval");
		response.addCookie(chocolateChip);
		
		//we can also access the cookies which come back with a request:
		//Cookie[] cookies =request.getCookies();
		
		//when we no longer want a cookie, we set its max age to 0 seconds
		//chocolateChip.setMaxAge(0);
		
		//if we use cookie.setHttpOnly(true) itll be harder to access our cookies from the client side
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
