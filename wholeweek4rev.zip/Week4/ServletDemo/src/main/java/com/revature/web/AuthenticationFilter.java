package com.revature.web;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/*
 * 
 */
public class AuthenticationFilter implements Filter {

	public AuthenticationFilter() {
		// TODO Auto-generated constructor stub
	}

	public void destroy() {
		// TODO Auto-generated method stub
	}

	/*
	 * this do filter method is where we will implement our authentication logic.
	 * Note that if there are any other filters, the requests and response will be
	 * passed to those filters down the filter chain after they pass through this
	 * filter.
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		/*
		 * because this method takes a generic ServletRequest and ServletResponse, we'll
		 * need to cast these as HttpServletRequest and Response objs in order to access
		 * the methods we want
		 */
		
		HttpServletRequest req = (HttpServletRequest)request;
		HttpServletResponse res = (HttpServletResponse)response;
		
		//checking to see if this session exists
		HttpSession session = req.getSession(false);
		
		if(session == null) {
			res.sendRedirect("../index.html");
		
		}

		// pass the request along the filter chain
		chain.doFilter(request, response);
	}

	public void init(FilterConfig fConfig) throws ServletException {
	}

}
