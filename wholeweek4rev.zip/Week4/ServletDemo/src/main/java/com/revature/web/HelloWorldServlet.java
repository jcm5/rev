package com.revature.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 * This is a servlet. In order to create a servlet, we only have to extend the 
 * HttpServlet HttpServlet class. "Now it's a servlet" -Anthony
 *  
 */

/*
 * GET and POST Spiel: 
 * 
 * Get and post are both http verbs which have conventional uses. Though we put most 
 * of our logic in the doGet method, there is a technical difference between how get 
 * and post work.
 * 
 * Get appends info that is sent to server side to the URL. As a result, it is considered bad practice 
 * to send sensitive user info to the server using a GET request. GET also has a relatively small limit
 * to how much data you can send to the server side. It has a limit of 2048 characters
 * 
 * POST appends the info that is sent to the server to the body of the request. As a result, the amount of 
 * info you can send is near limitless.
 */
public class HelloWorldServlet extends HttpServlet {

	/**
	 * don't really need this
	 */
	private static final long serialVersionUID = 1L;

	// this is the method signature for the doGet method
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		/*
		 * doGet handles GET requests from the client side
		 */

		/*
		 * PrintWriter is not specific to the servlet API, but we can get an instance of
		 * the PrintWriter that writes to our response body by using the getWriter()
		 * method.
		 * 
		 * ON QUIZ: NOT "getPrintWriter"
		 */
		PrintWriter write = response.getWriter();
		/*
		 * in this case,we have written plain text to our response body. We are not,
		 * however, limited to plain text. We can also write back html, json, and many
		 * more.
		 * 
		 * example of content types: "application/json" "text/html" "text/plain
		 */
		response.setContentType("text/plain");

		// we use the print method to write something to our response body
		// write.print("whattup earth");
		write.println(this.getServletConfig().getInitParameter("Some Key"));
		write.println(this.getServletContext().getInitParameter("Some Global Key"));
	}

	// this is the method signature for the doPost method
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {

		/*
		 * doGet handles POST requests from the client side
		 */
	}

	/*
	 * just printing to the console, that is the only reason we are using the main
	 * method
	 */

}
