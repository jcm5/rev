package com.revature.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletLifeCycle
 */
public class ServletLifeCycle extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ServletLifeCycle() {
		super();
	}

	/*
	 * this is the init() method. It is called if our servlet has not year been
	 * instantiated. Note that it is only called once during service life cycle
	 */
	public void init() throws ServletException {
		// TODO Auto-generated method stub
		super.init();
	}

	/*
	 * This is our service() method. This method may be invoked several times during
	 * a servlet's life cycle. Note that methods such as doGet and doPost are called
	 * within this method
	 */
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.service(req, resp);
	}

	
	/*
	 * This is our service() method. it is only called once during a servlet's life
	 * cycle. If for instance, the servlet has been idle for some amount of time,
	 * this method will be called.
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		super.destroy();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
