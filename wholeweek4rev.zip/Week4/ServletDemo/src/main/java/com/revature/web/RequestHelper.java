package com.revature.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.revature.service.MemberService;

public class RequestHelper {

	/*
	 * Lets create a logger:
	 */

	private static final Logger loge = LogManager.getLogger(RequestHelper.class);
	/*
	 * this request helper will be used to implement the logic that determines what
	 * our front controller will send back to the client side
	 */

	public static Object processGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		loge.debug("in the Request Helper");
		String uri = request.getRequestURI().replace("/ServletDemo/getflix/api/", "");
		loge.debug(uri);
		switch(uri) {
		//this endpoint returns a list of members
		case "/members":
			return new MemberService().getAllMembers();
			//could still access request.getParameter and such
			
		//this is the default endpoint if no match is found	
		default:
			return "no such endpoint";
		}
	}
}
