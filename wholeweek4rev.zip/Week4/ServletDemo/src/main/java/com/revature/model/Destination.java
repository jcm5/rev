package com.revature.model;

public class Destination {
	private int destination_id;
	private String name;
	private String address;
	private int cost_per_person;
	private String additional_notes;
	
	
	public Destination() {
		super();
	}

	public Destination(int destination_id, String name, String address, int cost_per_person, String additional_notes) {
		super();
		this.destination_id = destination_id;
		this.name = name;
		this.address = address;
		this.cost_per_person = cost_per_person;
		this.additional_notes = additional_notes;
	}


	public int getDestination_id() {
		return destination_id;
	}


	public void setDestination_id(int destination_id) {
		this.destination_id = destination_id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public int getCost_per_person() {
		return cost_per_person;
	}


	public void setCost_per_person(int cost_per_person) {
		this.cost_per_person = cost_per_person;
	}


	public String getAdditional_notes() {
		return additional_notes;
	}


	public void setAdditional_notes(String additional_notes) {
		this.additional_notes = additional_notes;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((additional_notes == null) ? 0 : additional_notes.hashCode());
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + cost_per_person;
		result = prime * result + destination_id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Destination other = (Destination) obj;
		if (additional_notes == null) {
			if (other.additional_notes != null)
				return false;
		} else if (!additional_notes.equals(other.additional_notes))
			return false;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (cost_per_person != other.cost_per_person)
			return false;
		if (destination_id != other.destination_id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return 	destination_id + "    " + name + "    " + address +
				"    " + "$"+ cost_per_person + "    " + additional_notes; 	
	}

	
	

}
