package com.revature.service;

import java.util.List;

import com.revature.model.Member;
import com.revature.repository.MemberRepositoryImpl;

public class MemberService {

	public List<Member> getAllMembers() {
		return new MemberRepositoryImpl().getAllMembers();
	}
	
	public Member getMemberByID(int id) {
		return new MemberRepositoryImpl().getMemberById(id);
	}
	
	public void insertMember(Member m) {
		new MemberRepositoryImpl().insertMember(m);
	}
	
	public void deleteMember(Member m) {
		new MemberRepositoryImpl().deleteMember(m);		
	}
	
	public void updateMember(Member m) {
		new MemberRepositoryImpl().updateMember(m);
	}
}
