package com.revature.model;

public class Member {
	
	private int member_id;
	private String name;
	private String phone_number;
	private String school_email;
	private String medical_conditions;
	
	public Member() {
		super();
	}

	public Member(int member_id, String name, String phone_number, String school_email, String medical_conditions) {
		super();
		this.member_id = member_id;
		this.name = name;
		this.phone_number = phone_number;
		this.school_email = school_email;
		this.medical_conditions = medical_conditions;
	}

	public int getMember_id() {
		return member_id;
	}

	public void setMember_id(int member_id) {
		this.member_id = member_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public String getSchool_email() {
		return school_email;
	}

	public void setSchool_email(String school_email) {
		this.school_email = school_email;
	}

	public String getMedical_conditions() {
		return medical_conditions;
	}

	public void setMedical_conditions(String medical_conditions) {
		this.medical_conditions = medical_conditions;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((medical_conditions == null) ? 0 : medical_conditions.hashCode());
		result = prime * result + member_id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((phone_number == null) ? 0 : phone_number.hashCode());
		result = prime * result + ((school_email == null) ? 0 : school_email.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Member other = (Member) obj;
		if (medical_conditions == null) {
			if (other.medical_conditions != null)
				return false;
		} else if (!medical_conditions.equals(other.medical_conditions))
			return false;
		if (member_id != other.member_id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (phone_number == null) {
			if (other.phone_number != null)
				return false;
		} else if (!phone_number.equals(other.phone_number))
			return false;
		if (school_email == null) {
			if (other.school_email != null)
				return false;
		} else if (!school_email.equals(other.school_email))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return member_id + "      "+ name  + "      " + phone_number + "      " + school_email + "      " + medical_conditions;
	}
	
	
	
	
}
