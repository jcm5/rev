package com.revature.web;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/*
 * an alternative to cookies is JSessions. we can use JSessions to track user interactions with our applications. 
 * JSessions store an ID on the server side and some information on the client side.
 * 
 * If you are using JSessions, your API is not 100% RESTful because you store state on the server. All REST should
 * be stateless if you're purely RESTful
 */
public class JSession extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public JSession() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//get session returns the users current session or creates one if it doesnt exist.
		HttpSession session = request.getSession();
		
		//we can also set session attributes to access later
		session.setAttribute("username", "whatever my username is");
		
		//remove attributes using the attribute name:
		//session.removeAttribute("username")
		
		
		//when we want to invalidate a session, we should first check that the uer has one and 
		//then invalidate it. Using false will not create a new session
		HttpSession sessionIWillInvalidate = request.getSession(false);
		if(sessionIWillInvalidate != null) {
			sessionIWillInvalidate.invalidate();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
