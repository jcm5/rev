package com.revature.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.revature.model.Member;
import com.revature.service.MemberService;

public class FormData extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public FormData() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// We can use get parameter method to access parameters that have been sent in
		// the request body. Note that we must access these by their 'name' attribute

		/*
		 * we are using member service to retrieve all movies from our db. we will use
		 * these movies as user credentials because there is no user table
		 */

		MemberService ms = new MemberService();

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		System.out.println(username);
		System.out.println(password);

		/*
		 * lets check that uname and pass arent empty strings or null since the form can
		 * be manipulated from the client side. This is why we say that client side
		 * validation is NOT enough
		 * 
		 * 
		 * once we get user info, we should perform some check on it to make sure it is
		 * valid and that we can authenticate our user
		 * 
		 * member_id":4,"name":"bob barker"
		 */

		if (username != null && !username.equals("") && (password != null && !password.equals(""))) {

			Member m = ms.getMemberByID(Integer.parseInt(password));
			if (username.equals(m.getName()) && password.equals(String.valueOf(m.getMember_id()))) {
				
				
				
				HttpSession session = request.getSession();

				//adding session attribute
				session.setAttribute("role", "benco");
				
				
				/*
				 * there are several ways to handle redirecting traffic. we can use a Request
				 * dispatcher to forward requests or use a sendRedirect() method. Note that
				 * these two approaches, however, do not work exactly the same
				 * 
				 * RequestDispatcher
				 * ==================
				 * 
				 * our request dispatcher forwards our request to a new resource without the
				 * request ever leaving the server side. the client IS going to get a response
				 * after making a single request
				 * 
				 * sendRedirect
				 * ================== 
				 * our sendRedirect() method will send a response back to the client and send
				 * another request to the server. This means that two requests will have been
				 * made in the end. As a result, this isn't as fast as using a
				 * RequestDispatcher. 
				 * 
				 * sendRedirect() also obscures the initial resources URL
				 * whereas RequestDispatcher does NOT do this
				 */
				//RequestDispatcher dispatchy = request.getRequestDispatcher("./Views/home.html");
				//dispatchy.forward(request, response);
				
				response.sendRedirect("./Views/home.html");
			} else {
				//RequestDispatcher dispatchy = request.getRequestDispatcher("./404"
				//		+ ".html");
				//dispatchy.forward(request, response);
				response.sendRedirect("./Views/404.html");
			}
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
