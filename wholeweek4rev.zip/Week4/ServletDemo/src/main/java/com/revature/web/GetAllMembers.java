package com.revature.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.revature.service.MemberService;

/**
 * Servlet implementation class GetAllMovies
 */
public class GetAllMembers extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public GetAllMembers() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		MemberService ms = new MemberService();

		//PrintWriter writer = response.getWriter();

		response.setContentType("application/json" + '\n');

		/*
		 * NOTE: this ObjectMapper does not come from the Servlet API. We've included
		 * the Jackson Databind dependency, which gives us access to ObjectMapper. an OM
		 * provides a convenient way of mapping out Java objects as JSON and vice versa
		 */
		ObjectMapper imTheMap = new ObjectMapper();

		/*
		 * NOTE we are writing the info from our database back to the client as json. in
		 * order to "consume" this REST, we need only hit the appropriate endpoint. In
		 * this case, the endpoint we must hit to access our data is:
		 * 
		 * http://localhost:8080/ServletDemo/GetAllMembers
		 */
		//writer.println(imTheMap.writeValueAsString(ms.getAllMembers()));

		//if you want to write in bytes, get a servlet output steam instead of a print writer
		response.getOutputStream().write(imTheMap.writeValueAsBytes(ms.getAllMembers()));
		
		/*
		 * response.setContentType("text/html"); String in =
		 * request.getParameter("member_id"); int id = Integer.valueOf(in);
		 * 
		 * try { Member m = ms.getMemberByID(id); String name = m.getName();
		 * writer.print("<h2>The name assoiciated with this id is:</h2>");
		 * writer.print("<h3>" + name + "</h3>");
		 * 
		 * } catch (Exception e) { e.printStackTrace(); } finally { writer.close(); }
		 */

		// response.setContentType("application/json");

		/*
		 * NOTE: this ObjectMapper does not come from the Servlet API. We've included
		 * the Jackson Databind dependency, which gives us access to ObjectMapper. an OM
		 * provides a convenient way of mapping out Java objects as JSON and vice versa
		 */
		// ObjectMapper imTheMap = new ObjectMapper();
		// writer.println(imTheMap.writeValueAsString(ms.getAllMembers()));

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// note that doPost calls do getGet. This means that we only HAVE to implement
		// the doGet() method
		// regardless of whether we recieve a GET or POST request, doGet's logic will be
		// invoked.
		doGet(request, response);
	}

}
