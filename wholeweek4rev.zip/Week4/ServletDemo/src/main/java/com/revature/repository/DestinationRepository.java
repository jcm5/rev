package com.revature.repository;

import java.util.List;

import com.revature.model.Destination;

public interface DestinationRepository {
	List<Destination> getAllDestinations();
	Destination getDestinationById(int id);
	void insertDestination(Destination d);
	void deleteDestination(Destination d);
	void updateDestination(Destination d);
}
