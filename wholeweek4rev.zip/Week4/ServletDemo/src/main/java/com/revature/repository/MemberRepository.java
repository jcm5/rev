package com.revature.repository;

import java.util.List;

import com.revature.model.Member;

public interface MemberRepository {
	
	List<Member> getAllMembers();
	Member getMemberById(int id);
	void insertMember(Member m);
	void deleteMember(Member m);
	void updateMember(Member m);


}
