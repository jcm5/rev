package com.revature.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.revature.model.Member;
import com.revature.util.ConnectionClosers;
import com.revature.util.ConnectionFactory;

public class MemberRepositoryImpl implements MemberRepository {

	public List<Member> getAllMembers() {
		List<Member> members = new ArrayList<Member>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		final String SQL_QUERY = "select * from clubmanagerschema.members";

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.createStatement();
			rs = stmt.executeQuery(SQL_QUERY);
			while (rs.next()) {
				members.add(
						new Member(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return members;
	}

	public Member getMemberById(int id) {
		Member m = new Member();
		Connection conn = null; // we NEED a connection to access our DB
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("select * from clubmanagerschema.members where member_id = ?");
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			if (rs.next()) {
				m.setMember_id(rs.getInt(1));
				m.setName(rs.getString(2));
				m.setPhone_number(rs.getString(3));
				m.setSchool_email(rs.getString(4));
				m.setMedical_conditions(rs.getString(5));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeAll(conn, stmt, rs);
		}
		return m;
	}

	public void insertMember(Member m) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("insert into clubmanagerschema.members values(default, ?, ?, ?, ?)");
			stmt.setString(1, m.getName());
			stmt.setString(2, m.getPhone_number());
			stmt.setString(3, m.getSchool_email());
			stmt.setString(4, m.getMedical_conditions());
			stmt.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}
	}

	public void deleteMember(Member m) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("delete from clubmanagerschema.members where (member_id = ?)");
			stmt.setInt(1, m.getMember_id());
			stmt.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}
	}

	public void updateMember(Member m) {
		Connection conn = null;
		PreparedStatement stmt = null;

		try {
			conn = ConnectionFactory.getConnection();
			stmt = conn.prepareStatement("update clubmanagerschema.members set member_id = ?, "
					+ "member_name = ?, phone = ?, school_email = ?, medical_condition = ? where (member_id = ?)");
			stmt.setInt(1, m.getMember_id());
			stmt.setString(2, m.getName());
			stmt.setString(3, m.getPhone_number());
			stmt.setString(4, m.getSchool_email());
			stmt.setString(5, m.getMedical_conditions());
			stmt.setInt(6, m.getMember_id());
			stmt.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			ConnectionClosers.closeConnection(conn);
			ConnectionClosers.closeStatement(stmt);
		}
	}
}
